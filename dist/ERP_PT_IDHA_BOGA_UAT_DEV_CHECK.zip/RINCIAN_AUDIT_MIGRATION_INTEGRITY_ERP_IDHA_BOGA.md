# Audit Migration Integrity ERP Idha Boga

Laporan ini read-only. Checksum digunakan untuk membuktikan file migration lama tidak berubah antar lingkungan.

## Ringkasan

| Metrik | Nilai |
| --- | --- |
| Status | PASS |
| Total migration file | 42 |
| Root revision | 1 |
| Head revision | 1 |
| Branch point | 0 |
| Duplicate revision | 0 |
| Missing revision var | 0 |
| Missing parent | 0 |

## Heads

| Revision |
| --- |
| 85a0a1b2c3d4 |

## Roots

| Revision |
| --- |
| 7f1f6b158032 |

## Branch Points

| Revision |
| --- |

## Issues

| Jenis | Detail |
| --- | --- |

## Checklist Verifikasi Database

- Jalankan `flask db heads` dan pastikan sama dengan Head revision di report ini.

- Jalankan `flask db current` pada database target dan pastikan tidak tertinggal.

- Jalankan `flask db upgrade` pada database kosong.

- Jalankan `flask db upgrade` pada snapshot versi sebelumnya.

- Bandingkan `MIGRATION_CHECKSUM_MANIFEST_ERP_IDHA_BOGA.tsv` antar repository, laptop, backup, ZIP, dan production.

- Jika revision yang sama punya checksum berbeda, jangan deploy. Buat migration koreksi baru.

## Manifest

| File | Revision | Down Revision | SHA-256 |
| --- | --- | --- | --- |
| migrations/versions/55b0b1c2d3e4_supplier_master_optional.py | 55b0b1c2d3e4 | 7e141fc5adf3 | 3bb8f2e480ef60025ce5cf8c0437aca7560a92c37033e02d520622791a7cc368 |
| migrations/versions/55f0c1d2e3f4_supplier_bill_accounts_payable.py | 55f0c1d2e3f4 | 55b0b1c2d3e4 | 2c248d73ea7ede756d2ea8c2a1c50a691156d430984a6a34245b7ff59105f633 |
| migrations/versions/55g0d1e2f3a4_supplier_payment_accounts_payable.py | 55g0d1e2f3a4 | 55f0c1d2e3f4 | 1b2357f9dab305f592f27308bf133465c63ed744f82aca63800cc5c12e3ae546 |
| migrations/versions/56a0e1f2a3b4_item_cost_profile_unit_conversion.py | 56a0e1f2a3b4 | 55g0d1e2f3a4 | dde6d355a72d174010251959e3be32d535690859d227b70ab9dae2d7157c4154 |
| migrations/versions/56b0f1a2b3c4_recipe_bom_hpp_calculator.py | 56b0f1a2b3c4 | 56a0e1f2a3b4 | ebb2cf1a3a54cc65e27a314b612f9e734e4d8101f8949aeda9d257612742bdec |
| migrations/versions/56c0a1b2c3d4_packaging_overhead_profiles.py | 56c0a1b2c3d4 | 56b0f1a2b3c4 | b47e164c12441651c19f10251d966a83e5481dc977544dd69f757d4a77e59c44 |
| migrations/versions/56e0b1c2d3e4_order_hpp_snapshot_manual.py | 56e0b1c2d3e4 | 56c0a1b2c3d4 | 9418659ebeb14d479e67bd4cdc3ea6a39da0834a77adcb68533a145eb2352e28 |
| migrations/versions/56j0c1d2e3f4_hpp_stock_consumption_commit.py | 56j0c1d2e3f4 | 56e0b1c2d3e4 | b76684a1e9f710bc200ff55dae8cb35d49a524c573968de2c2c48d3dfc133aa5 |
| migrations/versions/56k0d1e2f3a4_order_default_hpp_profile.py | 56k0d1e2f3a4 | 56j0c1d2e3f4 | 4df96bf98df7159941a2994c74b77534f0ca05009dd94d852681ce9292043239 |
| migrations/versions/56l0e1f2a3b4_hpp_allocation_per_order_detail.py | 56l0e1f2a3b4 | 56k0d1e2f3a4 | 990db2eb012b825757ced33570d906f8c9d139946f2e52f70084de0f4046a529 |
| migrations/versions/57a0f1a2b3c4_cash_bank_opening_transfer_reconciliation.py | 57a0f1a2b3c4 | 56l0e1f2a3b4 | 3a127001550e655a5e66bfd8d495aded876c11b7d31bf95a8d85b9c7b71c49d7 |
| migrations/versions/58a0a1b2c3d4_audit_log_schema_upgrade.py | 58a0a1b2c3d4 | 57a0f1a2b3c4 | 44666b19b5cd1dfc0720bb51641e6530603d52ed2a76dc0b241adcaf1590e375 |
| migrations/versions/60c0a1b2c3d4_recipe_status_version_note.py | 60c0a1b2c3d4 | 58a0a1b2c3d4 | 89d8b3145c327ef124ad0463bccaf12b43ecd1e385e25c3ec8629444392e91c7 |
| migrations/versions/60f0a1b2c3d4_digital_attachment_foundation.py | 60f0a1b2c3d4 | 60c0a1b2c3d4 | 5354b5e251eb4fe38cbe4f7960db8be8d48e3fac5e4f26ad0b9208b0500548c3 |
| migrations/versions/62b0a1b2c3d4_fixed_asset_purchase_cash_bank.py | 62b0a1b2c3d4 | 60f0a1b2c3d4 | 3d1573b20073144fde48cecc5cc5395a816f16638533b4fa7b62ce6308ca8cf9 |
| migrations/versions/63b0a1b2c3d4_persistent_notification_schema_service.py | 63b0a1b2c3d4 | 62b0a1b2c3d4 | 6a65c717d7288ff8a85dc3a18e48f8c94a56f90f05de411c66488ea315318cb0 |
| migrations/versions/63f0a1b2c3d4_recipe_version_snapshot_schema.py | 63f0a1b2c3d4 | 63b0a1b2c3d4 | 874ac5ca9fee4570a1f8460e3932848344845e39e13ca2bbd874f3f331fa9bb0 |
| migrations/versions/66c0a1b2c3d4_optional_advance_dp_flow.py | 66c0a1b2c3d4 | 63f0a1b2c3d4 | 8a376e012b0ab06789543d0400b407ee5abcb6f2d47feff0fc9af7fa055d1512 |
| migrations/versions/66d0a1b2c3d4_transport_vehicle_fuel_expense_coa_mapping.py | 66d0a1b2c3d4 | 66c0a1b2c3d4 | 64ee982d08f69cf33df80022f17127897dc3ade844a47b37a02324dba1b313f9 |
| migrations/versions/66e0a1b2c3d4_operational_expense_coa_mapping.py | 66e0a1b2c3d4 | 66d0a1b2c3d4 | 71dbd138070682ad3ac452a19099c19f3ad0ba63f6da9a029ce59a0dddf47dd5 |
| migrations/versions/66f0a1b2c3d4_optional_fixed_asset_depreciation_engine.py | 66f0a1b2c3d4 | 66e0a1b2c3d4 | 94704f0d7964c9040df39c84a903ce5995e96e97fb1ba49c4bf29ecf26ce2c50 |
| migrations/versions/66g0a1b2c3d4_period_closing_retained_earnings.py | 66g0a1b2c3d4 | 66f0a1b2c3d4 | 6cede3379ceba5eb0a7ab55694cbe02adba56a6c1aadc3d5a529f2891bb89976 |
| migrations/versions/69d0a1b2c3d4_canteen_payment_method_external_buyer.py | 69d0a1b2c3d4 | 66g0a1b2c3d4 | 64522c7521fb28c2ddff0cc0b08353d40d70fe0f3340108a1144335dffb5358a |
| migrations/versions/69e0a1b2c3d4_official_invoice_identity_client_pic_lock.py | 69e0a1b2c3d4 | 69d0a1b2c3d4 | cf62099d2b0c83c3d54e5b4ec4692dd8ecbb7f36391b481e8aa4e5472e4c9953 |
| migrations/versions/69i0a1b2c3d4_operational_sla_late_accuracy.py | 69i0a1b2c3d4 | 69e0a1b2c3d4 | 568f4266094a9c35f890d12b420a2ac7179e2ca66dd343b270a63a7287393b95 |
| migrations/versions/71f0a1b2c3d4_asset_vehicle_installment_foundation.py | 71f0a1b2c3d4 | 69i0a1b2c3d4 | ac43fcc34c46f7a6aaf317216572c01878b936f52c904933c19f25e7e88c432d |
| migrations/versions/72a0a1b2c3d4_postgres_runtime_invoice_schema_alignment.py | 72a0a1b2c3d4 | 71f0a1b2c3d4 | 765e0dd598e0c00e080754824d22901819ecf9510c07ccbc4c6da148247380a9 |
| migrations/versions/73a0a1b2c3d4_production_audit_performance_indexes.py | 73a0a1b2c3d4 | 72a0a1b2c3d4 | ccec25bd743a2c8534e4b065da9514d59d04f91a817566006971dedad2cd7eed |
| migrations/versions/74a0a1b2c3d4_invoice_source_unique_constraint.py | 74a0a1b2c3d4 | 73a0a1b2c3d4 | 0b0468a2c37cfbe38ac8ab4e66e2f9796e94808911329e7ff4a156d11732c406 |
| migrations/versions/75a0a1b2c3d4_field_transaction_foundation.py | 75a0a1b2c3d4 | 74a0a1b2c3d4 | 9088b4f22029c80c3e748f6c83b03a7e2047f2e62c4c52e64db162fc152baa00 |
| migrations/versions/76a0a1b2c3d4_bank_account_coa_mapping.py | 76a0a1b2c3d4 | 75a0a1b2c3d4 | b67be382679e4ea9a107add6680331c26d8f1145a363ea85f64304ec2e3df483 |
| migrations/versions/77a0a1b2c3d4_manual_receivable_payable_foundation.py | 77a0a1b2c3d4 | 76a0a1b2c3d4 | 70f8aabbdd4325461993b5533442da4ef238d007e0571b4d175e665d1759396e |
| migrations/versions/78a0a1b2c3d4_manual_payment_accounting_trace.py | 78a0a1b2c3d4 | 77a0a1b2c3d4 | 60128411b7d66fdcec4950827a591f14c4034d9b2e6824a597fd0fab8cd140ea |
| migrations/versions/79a0a1b2c3d4_manual_billing_recap_invoice.py | 79a0a1b2c3d4 | 78a0a1b2c3d4 | 73cae4eada5e772fd9e33b9c79898e3eb3dc50269a14948262f883dd8d51efb9 |
| migrations/versions/7e141fc5adf3_add_price_per_portion_to_order_revisions.py | 7e141fc5adf3 | 7f1f6b158032 | a06e704a259060634f0c2a64e39ef9953261bd8b476f8118b4593632fac1996f |
| migrations/versions/7f1f6b158032_rebuild_schema_for_multi_location_daily_.py | 7f1f6b158032 | - | 8e3b0a3240dd5df070964a267b3bc77f2d090b9048c18bb7720a58218d101dda |
| migrations/versions/80a0a1b2c3d4_invoice_input_source_foundation.py | 80a0a1b2c3d4 | 79a0a1b2c3d4 | 1ff0111a147ca82518639d9ee79916bbf77ffd0d49248dfbb1c930f3b1ff5d4a |
| migrations/versions/81a0a1b2c3d4_manual_backfill_batch_lock.py | 81a0a1b2c3d4 | 80a0a1b2c3d4 | 19307fe81c50ca53e07697f1cd6867d9e0b610fab5bc3d1bae5a72934e450d00 |
| migrations/versions/82a0a1b2c3d4_manual_backfill_flexible_bill_to.py | 82a0a1b2c3d4 | 81a0a1b2c3d4 | 5b1eea380064b45f35420665ba8bd78c5b68aedeb48d1d93b500e695541d8336 |
| migrations/versions/83a0a1b2c3d4_finance_accounting_numeric_wave.py | 83a0a1b2c3d4 | 82a0a1b2c3d4 | f860c35f007eccdb7ab4802829f1aa4e3cfd72d82ca30a69d36637291a8945a7 |
| migrations/versions/84a0a1b2c3d4_remaining_numeric_wave.py | 84a0a1b2c3d4 | 83a0a1b2c3d4 | eb19277f77a921854cbe3c43dccf63a04e0a669c0fdb3066a887f0d5a2cdae97 |
| migrations/versions/85a0a1b2c3d4_base_model_optimistic_locking.py | 85a0a1b2c3d4 | 84a0a1b2c3d4 | ed9cee03cdce233b7c779f9f6bbd58506709f8f9585d5e7d06028222c28696f3 |

