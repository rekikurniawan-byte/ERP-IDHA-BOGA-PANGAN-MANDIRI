# Audit Generic Exception ERP Idha Boga

Laporan ini read-only. Fokus P1 adalah handler yang menangkap semua Exception tanpa logger dan tanpa raise pada route, service transaksi, dashboard, backup, dan context processor.

## Ringkasan

| Metrik | Nilai |
| --- | --- |
| Total except Exception | 299 |
| P1 perlu logging/exception spesifik | 0 |
| P2 review bertahap | 299 |
| Handler tanpa logger dan tanpa raise | 0 |

## Per Scope

| Scope | Jumlah |
| --- | --- |
| route | 146 |
| service | 107 |
| dashboard/background-read | 25 |
| backup/recovery | 16 |
| app_factory/context/error_handler | 5 |

## Detail

| Prioritas | File | Line | Scope | Logged | Reraised |
| --- | --- | --- | --- | --- | --- |
| P2 | app/__init__.py | 100 | app_factory/context/error_handler | ya | tidak |
| P2 | app/__init__.py | 118 | app_factory/context/error_handler | ya | tidak |
| P2 | app/__init__.py | 169 | app_factory/context/error_handler | ya | tidak |
| P2 | app/__init__.py | 210 | app_factory/context/error_handler | ya | tidak |
| P2 | app/__init__.py | 226 | app_factory/context/error_handler | ya | tidak |
| P2 | app/routes/accounting_routes.py | 408 | route | ya | tidak |
| P2 | app/routes/accounting_routes.py | 451 | route | ya | tidak |
| P2 | app/routes/accounting_routes.py | 467 | route | ya | tidak |
| P2 | app/routes/accounting_routes.py | 475 | route | ya | tidak |
| P2 | app/routes/accounting_routes.py | 776 | route | ya | tidak |
| P2 | app/routes/accounting_routes.py | 1114 | route | ya | tidak |
| P2 | app/routes/accounting_routes.py | 1236 | route | ya | tidak |
| P2 | app/routes/accounting_routes.py | 1264 | route | ya | tidak |
| P2 | app/routes/accounting_routes.py | 1370 | route | ya | tidak |
| P2 | app/routes/accounting_routes.py | 1548 | route | ya | tidak |
| P2 | app/routes/accounting_routes.py | 1566 | route | ya | tidak |
| P2 | app/routes/accounting_routes.py | 1803 | route | ya | tidak |
| P2 | app/routes/accounting_routes.py | 1815 | route | ya | tidak |
| P2 | app/routes/accounting_routes.py | 2021 | route | ya | tidak |
| P2 | app/routes/accounting_routes.py | 2038 | route | ya | tidak |
| P2 | app/routes/accounting_routes.py | 2502 | route | ya | tidak |
| P2 | app/routes/auth_routes.py | 80 | route | ya | tidak |
| P2 | app/routes/canteen_routes.py | 59 | route | ya | tidak |
| P2 | app/routes/delivery_routes.py | 201 | route | ya | tidak |
| P2 | app/routes/delivery_routes.py | 253 | route | ya | tidak |
| P2 | app/routes/delivery_routes.py | 306 | route | ya | tidak |
| P2 | app/routes/delivery_routes.py | 376 | route | ya | tidak |
| P2 | app/routes/delivery_routes.py | 390 | route | ya | tidak |
| P2 | app/routes/delivery_routes.py | 410 | route | ya | tidak |
| P2 | app/routes/field_transaction_routes.py | 109 | route | tidak | ya |
| P2 | app/routes/field_transaction_routes.py | 116 | route | ya | tidak |
| P2 | app/routes/field_transaction_routes.py | 329 | route | ya | tidak |
| P2 | app/routes/field_transaction_routes.py | 406 | route | ya | tidak |
| P2 | app/routes/field_transaction_routes.py | 466 | route | ya | tidak |
| P2 | app/routes/field_transaction_routes.py | 505 | route | ya | tidak |
| P2 | app/routes/field_transaction_routes.py | 563 | route | ya | tidak |
| P2 | app/routes/field_transaction_routes.py | 683 | route | ya | tidak |
| P2 | app/routes/field_transaction_routes.py | 703 | route | ya | tidak |
| P2 | app/routes/field_transaction_routes.py | 724 | route | ya | tidak |
| P2 | app/routes/field_transaction_routes.py | 757 | route | ya | tidak |
| P2 | app/routes/field_transaction_routes.py | 798 | route | ya | tidak |
| P2 | app/routes/field_transaction_routes.py | 820 | route | ya | tidak |
| P2 | app/routes/field_transaction_routes.py | 848 | route | ya | tidak |
| P2 | app/routes/field_transaction_routes.py | 876 | route | ya | tidak |
| P2 | app/routes/field_transaction_routes.py | 925 | route | ya | tidak |
| P2 | app/routes/field_transaction_routes.py | 962 | route | ya | tidak |
| P2 | app/routes/field_transaction_routes.py | 995 | route | ya | tidak |
| P2 | app/routes/field_transaction_routes.py | 1030 | route | ya | tidak |
| P2 | app/routes/field_transaction_routes.py | 1059 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 904 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 917 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 1610 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 1680 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 1719 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 1805 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 1898 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 1909 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 1950 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 2011 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 2048 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 2226 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 2298 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 2527 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 2541 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 2552 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 2562 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 3133 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 3143 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 3278 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 3452 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 3462 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 3502 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 3665 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 3782 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 3796 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 3816 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 3991 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 3999 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 4414 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 4477 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 4538 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 4578 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 4607 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 4628 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 4677 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 4685 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 4946 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 4984 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 5080 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 5106 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 5120 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 5140 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 5204 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 5219 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 5226 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 5294 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 5736 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 5845 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 5999 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 6026 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 6054 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 6093 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 6173 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 6180 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 6188 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 6209 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 6311 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 6318 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 6325 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 6341 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 6422 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 6536 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 6644 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 6680 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 6742 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 6788 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 6921 | route | ya | tidak |
| P2 | app/routes/finance_routes.py | 6999 | route | ya | tidak |
| P2 | app/routes/health_routes.py | 19 | route | ya | tidak |
| P2 | app/routes/hr_routes.py | 477 | route | ya | tidak |
| P2 | app/routes/hr_routes.py | 560 | route | ya | tidak |
| P2 | app/routes/hr_routes.py | 594 | route | ya | tidak |
| P2 | app/routes/hr_routes.py | 631 | route | ya | tidak |
| P2 | app/routes/logistics_routes.py | 726 | route | ya | tidak |
| P2 | app/routes/logistics_routes.py | 813 | route | ya | tidak |
| P2 | app/routes/logistics_routes.py | 827 | route | ya | tidak |
| P2 | app/routes/logistics_routes.py | 847 | route | ya | tidak |
| P2 | app/routes/logistics_routes.py | 1268 | route | ya | tidak |
| P2 | app/routes/logistics_routes.py | 1444 | route | ya | tidak |
| P2 | app/routes/production_routes.py | 175 | route | ya | tidak |
| P2 | app/routes/settings_routes.py | 337 | route | ya | tidak |
| P2 | app/routes/settings_routes.py | 350 | route | ya | tidak |
| P2 | app/routes/settings_routes.py | 370 | route | ya | tidak |
| P2 | app/routes/settings_routes.py | 385 | route | ya | tidak |
| P2 | app/routes/settings_routes.py | 398 | route | ya | tidak |
| P2 | app/routes/settings_routes.py | 412 | route | ya | tidak |
| P2 | app/routes/settings_routes.py | 442 | route | ya | tidak |
| P2 | app/routes/settings_routes.py | 500 | route | ya | tidak |
| P2 | app/routes/settings_routes.py | 555 | route | ya | tidak |
| P2 | app/routes/settings_routes.py | 615 | route | ya | tidak |
| P2 | app/routes/settings_routes.py | 627 | route | ya | tidak |
| P2 | app/routes/settings_routes.py | 655 | route | ya | tidak |
| P2 | app/routes/settings_routes.py | 692 | route | ya | tidak |
| P2 | app/routes/settings_routes.py | 789 | route | ya | tidak |
| P2 | app/routes/settings_routes.py | 810 | route | ya | tidak |
| P2 | app/routes/settings_routes.py | 835 | route | ya | tidak |
| P2 | app/routes/settings_routes.py | 891 | route | ya | tidak |
| P2 | app/routes/settings_routes.py | 902 | route | ya | tidak |
| P2 | app/routes/settings_routes.py | 984 | route | ya | tidak |
| P2 | app/routes/settings_routes.py | 991 | route | ya | tidak |
| P2 | app/routes/settings_routes.py | 1025 | route | ya | tidak |
| P2 | app/services/accounting_expense_drilldown_service.py | 88 | service | ya | tidak |
| P2 | app/services/accounting_expense_drilldown_service.py | 152 | service | ya | tidak |
| P2 | app/services/accounting_expense_drilldown_service.py | 274 | service | ya | tidak |
| P2 | app/services/accounting_expense_drilldown_service.py | 307 | service | ya | tidak |
| P2 | app/services/accounting_posting_status_service.py | 68 | service | ya | tidak |
| P2 | app/services/accounting_posting_status_service.py | 97 | service | ya | tidak |
| P2 | app/services/accounting_posting_status_service.py | 244 | service | ya | tidak |
| P2 | app/services/accounting_posting_status_service.py | 275 | service | ya | tidak |
| P2 | app/services/accounting_posting_status_service.py | 306 | service | ya | tidak |
| P2 | app/services/accounting_posting_status_service.py | 374 | service | ya | tidak |
| P2 | app/services/accounting_service.py | 30 | service | tidak | ya |
| P2 | app/services/accounting_service.py | 458 | service | tidak | ya |
| P2 | app/services/accounting_service.py | 492 | service | tidak | ya |
| P2 | app/services/accounting_service.py | 505 | service | ya | tidak |
| P2 | app/services/accounting_service.py | 659 | service | tidak | ya |
| P2 | app/services/accounting_service.py | 680 | service | ya | tidak |
| P2 | app/services/accounts_payable_service.py | 26 | service | ya | tidak |
| P2 | app/services/advance_service.py | 36 | service | tidak | ya |
| P2 | app/services/advance_service.py | 134 | service | ya | tidak |
| P2 | app/services/advance_service.py | 148 | service | ya | tidak |
| P2 | app/services/atomic_failure_simulation_service.py | 61 | service | tidak | ya |
| P2 | app/services/atomic_failure_simulation_service.py | 74 | service | ya | tidak |
| P2 | app/services/atomic_failure_simulation_service.py | 83 | service | ya | tidak |
| P2 | app/services/atomic_transaction_audit_map_service.py | 118 | service | ya | tidak |
| P2 | app/services/atomic_transaction_service.py | 84 | service | ya | tidak |
| P2 | app/services/atomic_transaction_service.py | 92 | service | ya | tidak |
| P2 | app/services/atomic_transaction_service.py | 96 | service | ya | tidak |
| P2 | app/services/atomic_transaction_service.py | 129 | service | ya | tidak |
| P2 | app/services/atomic_transaction_service.py | 148 | service | ya | tidak |
| P2 | app/services/atomic_transaction_service.py | 159 | service | ya | tidak |
| P2 | app/services/atomic_transaction_service.py | 224 | service | tidak | ya |
| P2 | app/services/audit_log_service.py | 56 | service | ya | tidak |
| P2 | app/services/audit_log_service.py | 70 | service | ya | tidak |
| P2 | app/services/audit_log_service.py | 168 | service | ya | tidak |
| P2 | app/services/audit_log_service.py | 243 | service | ya | tidak |
| P2 | app/services/audit_log_service.py | 312 | service | ya | tidak |
| P2 | app/services/backup_service.py | 109 | backup/recovery | ya | tidak |
| P2 | app/services/backup_service.py | 139 | backup/recovery | ya | tidak |
| P2 | app/services/backup_service.py | 170 | backup/recovery | ya | tidak |
| P2 | app/services/backup_service.py | 189 | backup/recovery | ya | tidak |
| P2 | app/services/backup_service.py | 211 | backup/recovery | ya | tidak |
| P2 | app/services/backup_service.py | 446 | backup/recovery | ya | tidak |
| P2 | app/services/backup_service.py | 611 | backup/recovery | ya | tidak |
| P2 | app/services/backup_service.py | 639 | backup/recovery | ya | tidak |
| P2 | app/services/backup_service.py | 652 | backup/recovery | ya | tidak |
| P2 | app/services/backup_service.py | 682 | backup/recovery | ya | tidak |
| P2 | app/services/backup_service.py | 698 | backup/recovery | ya | tidak |
| P2 | app/services/backup_service.py | 708 | backup/recovery | ya | tidak |
| P2 | app/services/backup_service.py | 743 | backup/recovery | ya | tidak |
| P2 | app/services/billing_trace_service.py | 36 | service | ya | tidak |
| P2 | app/services/canteen_service.py | 34 | service | tidak | ya |
| P2 | app/services/cash_bank_service.py | 14 | service | tidak | ya |
| P2 | app/services/cash_bank_service.py | 22 | service | ya | tidak |
| P2 | app/services/catering_report_service.py | 17 | service | ya | tidak |
| P2 | app/services/catering_report_service.py | 26 | service | ya | tidak |
| P2 | app/services/costing_transaction_service.py | 11 | service | tidak | ya |
| P2 | app/services/daily_closing_service.py | 42 | service | ya | tidak |
| P2 | app/services/daily_closing_service.py | 110 | service | ya | tidak |
| P2 | app/services/dashboard_analytics_service.py | 115 | dashboard/background-read | ya | tidak |
| P2 | app/services/dashboard_analytics_service.py | 126 | dashboard/background-read | ya | tidak |
| P2 | app/services/dashboard_analytics_service.py | 170 | dashboard/background-read | ya | tidak |
| P2 | app/services/dashboard_analytics_service.py | 180 | dashboard/background-read | ya | tidak |
| P2 | app/services/dashboard_command_center_service.py | 23 | dashboard/background-read | ya | tidak |
| P2 | app/services/dashboard_command_center_service.py | 31 | dashboard/background-read | ya | tidak |
| P2 | app/services/dashboard_command_center_service.py | 103 | dashboard/background-read | ya | tidak |
| P2 | app/services/dashboard_service.py | 87 | dashboard/background-read | ya | tidak |
| P2 | app/services/dashboard_service.py | 96 | dashboard/background-read | ya | tidak |
| P2 | app/services/dashboard_service.py | 105 | dashboard/background-read | ya | tidak |
| P2 | app/services/dashboard_service.py | 115 | dashboard/background-read | ya | tidak |
| P2 | app/services/dashboard_service.py | 123 | dashboard/background-read | ya | tidak |
| P2 | app/services/dashboard_service.py | 572 | dashboard/background-read | ya | tidak |
| P2 | app/services/dashboard_service.py | 669 | dashboard/background-read | ya | tidak |
| P2 | app/services/dashboard_service.py | 727 | dashboard/background-read | ya | tidak |
| P2 | app/services/dashboard_service.py | 731 | dashboard/background-read | ya | tidak |
| P2 | app/services/dashboard_service.py | 769 | dashboard/background-read | ya | tidak |
| P2 | app/services/dashboard_service.py | 876 | dashboard/background-read | ya | tidak |
| P2 | app/services/dashboard_service.py | 880 | dashboard/background-read | ya | tidak |
| P2 | app/services/digital_attachment_service.py | 61 | service | ya | tidak |
| P2 | app/services/digital_attachment_service.py | 226 | service | tidak | ya |
| P2 | app/services/disaster_recovery_sop_service.py | 30 | backup/recovery | ya | tidak |
| P2 | app/services/disaster_recovery_sop_service.py | 44 | backup/recovery | ya | tidak |
| P2 | app/services/field_transaction_policy_service.py | 299 | service | tidak | ya |
| P2 | app/services/field_transaction_posting_service.py | 31 | service | ya | tidak |
| P2 | app/services/field_transaction_settlement_service.py | 43 | service | ya | tidak |
| P2 | app/services/final_visual_browser_qa_service.py | 131 | service | ya | tidak |
| P2 | app/services/final_visual_browser_qa_service.py | 173 | service | ya | tidak |
| P2 | app/services/finance_collection_service.py | 8 | service | tidak | ya |
| P2 | app/services/finance_collection_service.py | 18 | service | tidak | ya |
| P2 | app/services/finance_export_service.py | 246 | service | ya | tidak |
| P2 | app/services/finance_export_service.py | 466 | service | ya | tidak |
| P2 | app/services/fixed_asset_depreciation_service.py | 33 | service | tidak | ya |
| P2 | app/services/fixed_asset_depreciation_service.py | 87 | service | ya | tidak |
| P2 | app/services/fixed_asset_depreciation_service.py | 96 | service | ya | tidak |
| P2 | app/services/fixed_asset_installment_service.py | 79 | service | ya | tidak |
| P2 | app/services/fixed_asset_installment_service.py | 112 | service | ya | tidak |
| P2 | app/services/fixed_asset_purchase_service.py | 27 | service | tidak | ya |
| P2 | app/services/fixed_asset_purchase_service.py | 45 | service | ya | tidak |
| P2 | app/services/global_filter_service.py | 66 | service | ya | tidak |
| P2 | app/services/global_filter_service.py | 164 | service | ya | tidak |
| P2 | app/services/hpp_stock_consumption_service.py | 389 | service | ya | tidak |
| P2 | app/services/hpp_stock_consumption_service.py | 436 | service | ya | tidak |
| P2 | app/services/hr_service.py | 76 | service | tidak | ya |
| P2 | app/services/invoice_identity_service.py | 15 | service | tidak | ya |
| P2 | app/services/live_reminder_service.py | 85 | dashboard/background-read | ya | tidak |
| P2 | app/services/live_reminder_service.py | 435 | dashboard/background-read | ya | tidak |
| P2 | app/services/live_reminder_service.py | 440 | dashboard/background-read | ya | tidak |
| P2 | app/services/live_reminder_service.py | 514 | dashboard/background-read | ya | tidak |
| P2 | app/services/logistics_transaction_service.py | 10 | service | tidak | ya |
| P2 | app/services/manual_backfill_billing_service.py | 96 | service | tidak | ya |
| P2 | app/services/manual_backfill_billing_service.py | 106 | service | ya | tidak |
| P2 | app/services/manual_backfill_billing_service.py | 720 | service | ya | tidak |
| P2 | app/services/manual_backfill_billing_service.py | 763 | service | ya | tidak |
| P2 | app/services/manual_billing_service.py | 38 | service | tidak | ya |
| P2 | app/services/manual_billing_service.py | 46 | service | ya | tidak |
| P2 | app/services/master_data_service.py | 78 | service | tidak | ya |
| P2 | app/services/ml_prediction_service.py | 82 | service | ya | tidak |
| P2 | app/services/ml_prediction_service.py | 99 | service | ya | tidak |
| P2 | app/services/ml_prediction_service.py | 122 | service | ya | tidak |
| P2 | app/services/ml_prediction_service.py | 447 | service | ya | tidak |
| P2 | app/services/ml_prediction_service.py | 465 | service | ya | tidak |
| P2 | app/services/ml_prediction_service.py | 629 | service | ya | tidak |
| P2 | app/services/notification_service.py | 70 | dashboard/background-read | ya | tidak |
| P2 | app/services/notification_service.py | 174 | dashboard/background-read | ya | tidak |
| P2 | app/services/operational_expense_service.py | 24 | service | tidak | ya |
| P2 | app/services/operational_expense_service.py | 76 | service | ya | tidak |
| P2 | app/services/operational_expense_service.py | 86 | service | ya | tidak |
| P2 | app/services/operational_service.py | 11 | service | tidak | ya |
| P2 | app/services/order_to_cash_trace_service.py | 20 | service | ya | tidak |
| P2 | app/services/period_closing_service.py | 44 | service | ya | tidak |
| P2 | app/services/production_runtime_health_service.py | 83 | service | ya | tidak |
| P2 | app/services/production_runtime_health_service.py | 96 | service | ya | tidak |
| P2 | app/services/production_runtime_health_service.py | 115 | service | ya | tidak |
| P2 | app/services/production_runtime_health_service.py | 140 | service | ya | tidak |
| P2 | app/services/production_runtime_health_service.py | 150 | service | ya | tidak |
| P2 | app/services/production_runtime_health_service.py | 168 | service | ya | tidak |
| P2 | app/services/recovery_center_service.py | 82 | backup/recovery | ya | tidak |
| P2 | app/services/sensitive_action_guard_service.py | 143 | service | ya | tidak |
| P2 | app/services/sensitive_action_guard_service.py | 153 | service | ya | tidak |
| P2 | app/services/sensitive_action_guard_service.py | 266 | service | ya | tidak |
| P2 | app/services/system_health_service.py | 37 | service | ya | tidak |
| P2 | app/services/system_health_service.py | 45 | service | ya | tidak |
| P2 | app/services/system_health_service.py | 104 | service | ya | tidak |
| P2 | app/services/system_health_service.py | 233 | service | ya | tidak |
| P2 | app/services/transport_expense_service.py | 25 | service | tidak | ya |
| P2 | app/services/transport_expense_service.py | 56 | service | ya | tidak |
| P2 | app/services/transport_expense_service.py | 66 | service | ya | tidak |
| P2 | app/services/visual_sweep_service.py | 31 | service | ya | tidak |
| P2 | app/services/visual_sweep_service.py | 230 | service | ya | tidak |

## Rekomendasi

- Ganti generic exception dengan exception spesifik untuk validasi, database operational error, integrity error, dan file I/O.

- Jika fallback tetap diperlukan, gunakan logger.exception agar kegagalan tidak terlihat sebagai kondisi normal.

- Hindari mengubah kegagalan query ERP menjadi label aman seperti badge hijau tanpa sinyal error internal.

